package gameoflife;

import fcast.universe.world.cell.CellType;
import javafx.scene.paint.Color;

public class GOLCellType extends CellType{
	
	public GOLCellType(String valueName, Boolean value, Color color) {
		super(valueName, value, color);
	}

}
