package cellularTransport;

import fcast.universe.world.cell.CellType;
import javafx.scene.paint.Color;

public class CTCellType extends CellType{
	
	public CTCellType(String valueName, Integer value, Color color) {
		super(valueName, value, color);
	}

}
